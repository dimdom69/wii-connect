Stamp Sheet Creator Version 0.1
Created by Intrepid for use with WiiConnect Demo 5 and up.
This allows you, yes you, to create your own Stamp Sheets and upload them onto the internet via WiiConnect.

And here's how you do it:

First, open "Stamp Sheet Explanation", and create your Stamp Sheet based on that (it can be done in Notepad, Wordpad, or Microsoft Word).

Next, open "Text2Stamp Readme", read it, and use the Text2Stamp program.

Throughout the creator, there are several mentions of an ID Code. If you don't know the ID of the game, Google "Wii Saves", go to the first site that comes up, and type in the name of your game. The ID code is a 4-digit code, like RMGE for the North American Super Mario Galaxy, or RSPP for the Europian Wii Sports.

This program may have an automatic ID Code finder and a user-friendly GUI at some point, but due to my lack of coding skills, not now.

NOTE: If you want to get the hang of using this first, use the StampExample.txt file, and write your name in the "Creator" question, then use Text2Stamp to convert it (you don't have to rename the StampExample.txt file, so don't worry about what the Text2Stamp Readme says FOR THIS FILE ONLY!). Then, try opening it on WiiConnect to see if you did it right.