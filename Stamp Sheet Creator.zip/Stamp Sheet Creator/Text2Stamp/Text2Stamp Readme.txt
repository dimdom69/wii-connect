This is a simple program that converts some basic text formats to .stamps files, useable as Stamp Sheets with WiiConnect Demo 5 and up.

To use, take any .txt, .rtf, or .doc file you want to use as a Stamp Sheet (See Stamp Sheet explanation for how to create a useable one) and rename it to a digit between 1 and 9. (ie. 1.txt, 2.rtf, or 3.doc) Then, run the program.

Remember, if you have two or more file formats you want to convert to a .stamps file, use different numbers. For example, 1.txt and 1.rtf can NOT be in the same directory. 1.txt and 2.rtf will work, though.

After the files are converted, the program gives you the option to convert the .stamps files to .txt files. If you do not want to do this, close the program instead of pressing a key.

To make the files COMPLETELY useable, find the ID code of the game you're making a .stamps file for, and name it that (remember to keep the ".stamps" extension on the name, though). 
